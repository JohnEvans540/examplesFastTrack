package com.cooksys.examples;

import java.util.ArrayList;

public class ICantThinkOfAName
{
	public static void main(String[] args)
	{	
		
		ExtraFancyCar extraFancy = new ExtraFancyCar("I'm fancy!");
		
		extraFancy.honk();
		
		honkTheHorn(extraFancy);
		
		
		ArrayList<ExtraFancyCar> myList = new ArrayList<ExtraFancyCar>();
		
		myList.add(new ExtraFancyCar("Hi"));
		
		myList.get(0);
	}
	
	public static void honkTheHorn(Car car)
	{
		car.honk();
		car.printMakeAndModel();
		
		if(car instanceof ExtraFancyCar)
		{
			System.out.println("This Car is Extra Fancy!");
		}
	}
}
