package com.cooksys.examples;

public abstract class Car
{
	String make;
	String model;
	
	public void printMakeAndModel()
	{
		System.out.println(make +  " " + model);
	}
	
	public abstract void honk();
}
