package com.cooksys.examples;

public class FancyCar extends Car
{
	public FancyCar()
	{
		make = "FancyMake";
		model = "FancyModel";
	}

	@Override
	public void honk()
	{
		System.out.println("doot doot");
	}
	
	public void anything()
	{
		printMakeAndModel();
	}
}
