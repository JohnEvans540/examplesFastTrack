package com.cooksys.examples;

public class SingletonFactoryExample
{
	
	static int number = 1;
	
	private SingletonFactoryExample()
	{
		// TODO Auto-generated constructor stub
	}
	
	public static int getStuff()
	{
		number++;
		return number;
	}
	
	//visibility
	
	public void ex()
	{
		
	}
	
	void ex1()
	{
		
	}
	
	protected void ex2()
	{
		
	}
	
	private void ex3()
	{
		
	}
}
