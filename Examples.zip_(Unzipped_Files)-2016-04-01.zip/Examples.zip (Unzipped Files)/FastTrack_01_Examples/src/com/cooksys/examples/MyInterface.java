package com.cooksys.examples;

public interface MyInterface
{
	int printANumber();
	
	String blah();

}
