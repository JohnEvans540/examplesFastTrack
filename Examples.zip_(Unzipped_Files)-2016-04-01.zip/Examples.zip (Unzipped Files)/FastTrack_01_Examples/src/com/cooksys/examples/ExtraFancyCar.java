package com.cooksys.examples;

public class ExtraFancyCar extends FancyCar
{
	String noise;
	
	public ExtraFancyCar(String value)
	{
		noise = value;
	}
	
	public void honk()
	{
		System.out.println("honking horn!");
		super.honk();
	}
}
