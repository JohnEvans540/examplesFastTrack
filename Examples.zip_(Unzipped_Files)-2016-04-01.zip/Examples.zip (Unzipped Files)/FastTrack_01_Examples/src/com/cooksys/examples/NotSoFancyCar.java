package com.cooksys.examples;

public class NotSoFancyCar extends Car
{

	@Override
	public void honk()
	{
		System.out.println("squeak squeak");
	}

}
