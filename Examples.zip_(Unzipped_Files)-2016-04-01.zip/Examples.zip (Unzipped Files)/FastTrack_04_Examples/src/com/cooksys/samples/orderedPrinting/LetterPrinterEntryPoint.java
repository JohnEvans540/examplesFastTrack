package com.cooksys.samples.orderedPrinting;


public class LetterPrinterEntryPoint
{
	public static void main(String[] args)
	{
		Runnable r = new LetterPrintThread('a', 10);
		Runnable r1 = new LetterPrintThread('b', 10);
		Runnable r2 = new LetterPrintThread('c', 10);
		
		new Thread(r).start();
		new Thread(r1).start();
		new Thread(r2).start();
	}
}