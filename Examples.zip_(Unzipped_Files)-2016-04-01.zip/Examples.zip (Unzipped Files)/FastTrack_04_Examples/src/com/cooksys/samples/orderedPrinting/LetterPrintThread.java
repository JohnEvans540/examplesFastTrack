package com.cooksys.samples.orderedPrinting;

public class LetterPrintThread implements Runnable
{
	public static final Object LOCK = new Object();
	
	private static int MAX_FLAG_VALUE = 0;
	
	static int flag = 1;
	
	Character c;
	int iterations;
	int orderValue;
	
	public LetterPrintThread(Character c, int iterations)
	{
		this.c = c;
		this.iterations = iterations;
		orderValue = ++MAX_FLAG_VALUE;
	}
	
	@Override
	public void run()
	{
		int i = 0;
		while(i < iterations)
		{
			while(flag != orderValue)
			{
				try
				{
					Thread.sleep(10);
				}
				catch (InterruptedException e)
				{
					e.printStackTrace();
				}
			}
			System.out.println(c);
			i++;
			flag = flag == MAX_FLAG_VALUE ? 1 : flag + 1;
		}
	}
}
