package com.cooksys.samples.callable;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

public class ThreadReturnPrinter
{

	public static void main(String[] args) throws InterruptedException, ExecutionException
	{
		ReturnFromThread rft = new ReturnFromThread("!!! Thread Complete !!!");

		ExecutorService executor = Executors.newFixedThreadPool(10);

		Future<Integer> threadResult = executor.submit(rft);

		while (!threadResult.isDone())
		{
			System.out.println("waiting on thread");
		}
		
		System.out.println(threadResult.get());
		
		System.out.println("Done!");
		
		executor.shutdown();
	}

	
	
	
	public static void m(String[] args) throws InterruptedException, ExecutionException
	{
		ExecutorService executor = Executors.newFixedThreadPool(10);

		List<Future<Integer>> listOfResults = new ArrayList<Future<String>>();
		
		for (int i = 0; i < 10; i++)
		{
			listOfResults.add(executor.submit(new ReturnFromThread("Thread #" + i + " Has Completed")));
		}

		
		listOfResults.forEach(result ->
		{
			try
			{
				System.out.println(result.get());
			}
			catch (ExecutionException | InterruptedException inEx)
			{

			}
		});
		
		executor.shutdown();
	}
}
