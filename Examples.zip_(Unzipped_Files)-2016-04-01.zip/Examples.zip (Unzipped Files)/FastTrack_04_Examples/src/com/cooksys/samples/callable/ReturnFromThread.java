package com.cooksys.samples.callable;

import java.util.concurrent.Callable;
import java.util.concurrent.ThreadLocalRandom;

public class ReturnFromThread implements Callable<Integer>
{

	String value;
	
	public ReturnFromThread(String returnThisValue)
	{
		value = returnThisValue;
	}
	
	@Override
	public Integer call() throws Exception
	{
		int sleepyTime = ThreadLocalRandom.current().nextInt(1000, 10000 + 1);
		
		Thread.sleep(sleepyTime);
		return sleepyTime;
	}
}
