package com.cooksys.samples.join;

public class PrintAndWaitThread implements Runnable
{
	public static final Object LOCK = new Object();

	String printMe;
	int sleepTime;
	int itr;
	boolean synchronous;
	Thread joinOnMe;

	public PrintAndWaitThread(String value, int iterations, int sleepTime, boolean sync, Thread join)
	{
		printMe = value;
		this.sleepTime = sleepTime;
		itr = iterations;
		synchronous = sync;
		joinOnMe = join;
	}

	@Override
	public void run()
	{
		if(joinOnMe != null && joinOnMe.isAlive())
		{
			try
			{
				joinOnMe.join();
			}
			catch (InterruptedException e){}
		}
		
		if (synchronous)
		{	
			
			synchronized (LOCK)
			{
				printValues();
			}
		
		
		}
		else
		{
			printValues();
		}

	}

	public void printValues()
	{
		for (int i = 0; i < itr; i++)
		{
			System.out.println(printMe);
			try
			{
				Thread.sleep(sleepTime);
			}
			catch (InterruptedException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public void joinOn(Thread t)
	{
		joinOnMe = t;
	}
}
