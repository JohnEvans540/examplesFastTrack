package com.cooksys.samples.join;

public class JoinEntryPoint
{	
	public static void main(String[] args) throws InterruptedException
	{
		System.out.println("Creating Threads");
		
		Thread blahThread = new Thread(new PrintAndWaitThread("Blah", 10, 250, true, null));
		Thread uuughThread = new Thread(new PrintAndWaitThread("uuugh", 10, 250, true, null));
		Thread someThread = new Thread(new PrintAndWaitThread("something", 10, 250, true, null));
		
		
		blahThread.start();
		uuughThread.start();
		someThread.start();
		
		//uuughThread.join();
		//blahThread.join();
		
		
		
		
		
		
		System.out.println("Threads Started");
	}
}
