package com.cooksys.samples.thread;

public class ThreadStarter
{

	public static void main(String[] args)
	{
		System.out.println("Before Thread Start");
		
		ThreadExample exampleThread = new ThreadExample();
		Thread t = new Thread(exampleThread);
		t.start();
		t.start();
		
		try
		{
			Thread.sleep(2000);
		}
		catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("After Thread Start");

	}

}
