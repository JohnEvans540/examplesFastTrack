package com.cooksys.samples.thread;

public class ThreadExample implements Runnable
{
	public static final Object LOCK = new Object();
	
	public void run()
	{
		System.out.println("Hello from runnable");		
	}	
}
