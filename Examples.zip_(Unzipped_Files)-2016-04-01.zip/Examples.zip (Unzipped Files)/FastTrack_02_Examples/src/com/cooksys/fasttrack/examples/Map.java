package com.cooksys.fasttrack.examples;

import java.util.HashMap;

public class Map
{
	public static void main(String[] args)
	{
		HashMap<Integer, String> map = new HashMap<Integer, String>();
		
		map.put(1, "A");
		map.put(56, "B");
		map.put(938, "C");
		
		System.out.println("1:  " + map.get(1));
		
		System.out.println("2:  " + map.get(938));
		
		System.out.println("3:  " + map.get(5));
		
		map.put(56, "BBBB");
		
		System.out.println("4:  " + map.get(56));
		
		System.out.println("5:  " + map.put(938, "CCCCC"));
		
		System.out.println("6:  " + map.get(938));
	}
	
	
	public static void ternaryExample()
	{
		HashMap<String, Integer> hashMap = new HashMap<String, Integer>();
		
		Integer i;
		hashMap.put("Car", (i = hashMap.get("Car")) == null ? 1 : i + 1);
	}
}