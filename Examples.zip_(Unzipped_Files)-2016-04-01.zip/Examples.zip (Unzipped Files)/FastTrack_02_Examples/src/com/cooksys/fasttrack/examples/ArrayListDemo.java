package com.cooksys.fasttrack.examples;

import java.util.ArrayList;

public class ArrayListDemo
{
	public static void main(String[] args)
	{
		ArrayList<String> list = new ArrayList<String>(); 
		
		list.add("Hello");
		list.add("How");
		list.add("Are");
		list.add("You");
		list.add("?");
		
		for(String s : list)
		{
			System.out.println(s);
		}
		
		ArrayList<String> listNumberTwo = new ArrayList<String>();
		
		listNumberTwo.addAll(list);
		
		for(String s : listNumberTwo)
			System.out.println(s);
		
		list.get(4);
		
	}
}
