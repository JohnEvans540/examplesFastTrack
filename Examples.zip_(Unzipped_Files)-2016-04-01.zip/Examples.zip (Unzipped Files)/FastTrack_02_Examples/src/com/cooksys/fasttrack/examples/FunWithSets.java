package com.cooksys.fasttrack.examples;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.util.HashSet;

public class FunWithSets<E extends Object> extends HashSet<E> implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6670152480972263416L;
	private static Method clone;

	{
		try
		{
			//clone = Object.class.getMethod("clone");
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

	}

	@SuppressWarnings("unchecked")
	public FunWithSets(int base)
	{
		try
		{
			for (int i = 0; i < base; i++)
				add((E) ((Class) ((ParameterizedType) this.getClass().getGenericSuperclass()).getActualTypeArguments()[0]).newInstance());
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	public FunWithSets(int base, E copy)
	{
		try
		{
			for (int i = 0; i < base; i++)
				add((E) clone.invoke(copy));
		}
		catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public FunWithSets()
	{
		// TODO Auto-generated constructor stub
	}

	public void deepCloneFill(E cloneMe, int base)
	{
		try
		{
			for (int i = 0; i < base; i++)
			{
				ByteArrayOutputStream bos = new ByteArrayOutputStream();
				ObjectOutputStream oos = new ObjectOutputStream(bos);
				oos.writeObject(cloneMe);
				oos.flush();
				oos.close();
				bos.close();
				byte[] byteData = bos.toByteArray();

				ByteArrayInputStream bais = new ByteArrayInputStream(byteData);
				add((E) new ObjectInputStream(bais).readObject());
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
}
