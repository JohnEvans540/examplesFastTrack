package com.cooksys.fasttrack.examples;

public class SetLoop
{

	public static void main(String[] args)
	{
		FunWithSets<Object> funSet = new FunWithSets<>();
		
		funSet.deepCloneFill(new FunWithSets<Object>(), 5);
		
		System.out.println(funSet.size());
	}
}
