package com.cooksys.fasttrack.examples;

public class Loop
{
	public static void main(String[] args)
	{
		
		int sample = 10;
		
		for(int i = 0; i < sample; i++)
		{
			System.out.println(i);
		}
		
		/////
		
		ArrayGenerator generator = new ArrayGenerator(sample);
		
		for(int i = 0; i < sample; i++)
		{
			generator.acceptPerson(new Object());
		}
		
		/////
		
		Object[] array = generator.generateArray();
		
		for(Object o : array)
		{
			System.out.println(o.toString());
		}
		
		for(int i = 0; i < array.length; i++)
		{
			System.out.println(array[i]);
		}
		
	}
}
