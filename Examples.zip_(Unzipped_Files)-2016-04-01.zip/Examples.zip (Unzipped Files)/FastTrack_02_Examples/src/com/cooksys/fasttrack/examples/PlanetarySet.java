package com.cooksys.fasttrack.examples;

import java.util.HashSet;

public class PlanetarySet
{

	public static void main(String[] args)
	{
		HashSet<Planet> planetSet = new HashSet<Planet>();

		Planet a = new Planet("Earth");
		Planet b = new Planet("Mars");
		Planet c = new Planet("Pluto");
		Planet d = new Planet("Earth");
		
		System.out.println(a.name == d.name);
		
		planetSet.add(a);
		planetSet.add(b);
		planetSet.add(c);
		planetSet.add(d);
		
		System.out.println(planetSet.size());
	}

}
