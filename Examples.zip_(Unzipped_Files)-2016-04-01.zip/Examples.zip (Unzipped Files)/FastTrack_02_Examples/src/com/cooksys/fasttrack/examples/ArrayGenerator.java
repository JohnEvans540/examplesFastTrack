package com.cooksys.fasttrack.examples;

public class ArrayGenerator
{
	int max;
	int current = 0;
	Object[] array;
	
	public ArrayGenerator(int i)
	{
		max = i;
		array = new Object[max];
	}
	
	public void acceptPerson(Object p)
	{
		if(current < max)
			array[current++] = p;
	}
	
	public Object[] generateArray()
	{
		return array;
	}
}
