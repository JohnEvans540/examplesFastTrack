package com.cooksys.samples.file;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileSamples
{
	public static void main(String... args) throws Exception
	{
		File file = new File("C:/Users/CookSystems/Test.txt");
		
		if(!file.exists())
			file.createNewFile();
		
		//come back to this later
		FileWriter writer = new FileWriter(file);
		
		writer.write("Hello File");
		
		writer.flush();
		
		writer.close();
		
		//FileReader
		FileReader reader = new FileReader(file);
		
		int characterThatIRead;
		while((characterThatIRead = reader.read()) != -1)
			System.out.println((char)characterThatIRead);
		
		reader.close();
		
		//BufferedReader
		BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
		
		String line;
		while((line = bufferedReader.readLine()) != null)
			System.out.println(line);
		
		bufferedReader.close();
	}
	
	public static void whatever()
	{
			try
			{
				main("1", "2", "3");
			}
			catch (Exception e)
			{
				System.out.println("ioexception");
			}
			finally
			{
				//clean up
			}
	}
	
}
