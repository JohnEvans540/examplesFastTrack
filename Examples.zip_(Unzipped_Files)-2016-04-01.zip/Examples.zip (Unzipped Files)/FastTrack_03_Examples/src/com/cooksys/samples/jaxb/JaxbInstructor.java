package com.cooksys.samples.jaxb;

import java.beans.Transient;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

@XmlRootElement
public class JaxbInstructor
{
	private int id;
	
	private String firstName;
	
	private String lastName;
	
	private String homeTown;
	
	private String favoritePlanet;
	
	public JaxbInstructor()
	{
		// TODO Auto-generated constructor stub
	}
	
	public JaxbInstructor(int id, String firstName, String lastName, String homeTown, String favoritePlanet)
	{
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.homeTown = homeTown;
		this.favoritePlanet = favoritePlanet;
	}
	
	@Override
	public String toString()
	{
		// TODO Auto-generated method stub
		return "Instructor id: " + id + "\nfirstName: " + firstName + "\nlastName: " + lastName + "\nhomeTown: " + homeTown + "\nfavoritePlanet: " + favoritePlanet;
	}
	
	@XmlAttribute
	public int getId()
	{
		return id;
	}
	public void setId(int id)
	{
		this.id = id;
	}
	public String getFirstName()
	{
		return firstName;
	}
	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}
	public String getLastName()
	{
		return lastName;
	}
	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}
	public String getHomeTown()
	{
		return homeTown;
	}
	public void setHomeTown(String homeTown)
	{
		this.homeTown = homeTown;
	}
	
	@XmlTransient
	public String getFavoritePlanet()
	{
		return favoritePlanet;
	}
	public void setFavoritePlanet(String favoritePlanet)
	{
		this.favoritePlanet = favoritePlanet;
	}
	
}
