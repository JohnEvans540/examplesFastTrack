package com.cooksys.samples.jaxb;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import com.cooksys.samples.dom.Instructor;

public class JaxbWrite
{
	public static void main(String[] args)
	{
		JaxbInstructor michael = new JaxbInstructor(1, "Michael", "Boren", "Memphis", "Saturn");

		try
		{
			JAXBContext jaxbContext = JAXBContext.newInstance(JaxbInstructor.class);
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
			
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			
			File file = new File("C:/Users/CookSystems/JaxbTest.xml");
			jaxbMarshaller.marshal(michael, file);
			
			jaxbMarshaller.marshal(michael, System.out);

		}
		catch (JAXBException e)
		{
			e.printStackTrace();
		}

	}
}
