package com.cooksys.samples.jaxb;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class StringStuffList
{
	public static void main(String[] args)
	{
		new StringStuffList("s1", "s2", "s3");
	}

	public StringStuffList(String... ss)
	{
		List<String> hello = new ArrayList<String>(Arrays.asList(ss));
	}
}
