package com.cooksys.samples.jaxb;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

public class JaxbRead
{
	public static void main(String[] args)
	{
		try
		{
			File file = new File("C:/Users/CookSystems/JaxbTest.xml");
			JAXBContext jaxbContext = JAXBContext.newInstance(JaxbInstructor.class);

			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			JaxbInstructor instructor = (JaxbInstructor) jaxbUnmarshaller.unmarshal(file);
			System.out.println(instructor);
		}
		catch (JAXBException e)
		{
			e.printStackTrace();
		}
	}
}
