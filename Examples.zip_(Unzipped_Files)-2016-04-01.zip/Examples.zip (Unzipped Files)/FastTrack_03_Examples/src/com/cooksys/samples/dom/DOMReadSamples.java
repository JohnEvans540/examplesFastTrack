package com.cooksys.samples.dom;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class DOMReadSamples
{
	public static void main(String[] args) throws Exception
	{
		File fXmlFile = new File("C:/Users/CookSystems/Test.xml");
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document doc = dBuilder.parse(fXmlFile);

		System.out.println("Root element :" + doc.getDocumentElement().getNodeName());

		NodeList nList = doc.getElementsByTagName("Instructor");
		
		for (int temp = 0; temp < nList.getLength(); temp++)
		{
			Node node = nList.item(temp);

			System.out.println("\n    " + node.getNodeName());

			if (node.getNodeType() == Node.ELEMENT_NODE)
			{
				Element element = (Element) node;

				System.out.println("Instructor id : " + element.getAttribute("id"));
				System.out.println("First Name : " + element.getElementsByTagName("firstName").item(0).getTextContent());
				System.out.println("Last Name : " + element.getElementsByTagName("lastName").item(0).getTextContent());
				System.out.println("Home Town : " + element.getElementsByTagName("homeTown").item(0).getTextContent());
				System.out.println("Favorite Planet : " + element.getElementsByTagName("favoritePlanet").item(0).getTextContent());
			}
		}
	}
}
