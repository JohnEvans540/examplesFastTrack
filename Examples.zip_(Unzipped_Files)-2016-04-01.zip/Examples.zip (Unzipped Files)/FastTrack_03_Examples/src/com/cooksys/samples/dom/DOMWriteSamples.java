package com.cooksys.samples.dom;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class DOMWriteSamples
{
	public static void main(String[] args) throws Exception
	{
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		Document doc = docBuilder.newDocument();
		
		Element rootElement = doc.createElement("Instructors");
		
		doc.appendChild(rootElement);

		Instructor michael = new Instructor(1, "Michael", "Boren", "Bartlett", "Saturn");
		Instructor peter = new Instructor(2, "Peter", "Zastopil", "Berlin", "Jupiter");
		Instructor johnathan = new Instructor(3, "Johnathan", "Smith", "Memphis", "Mars");
		
		writeInstructor(doc, rootElement, michael);
		writeInstructor(doc, rootElement, peter);
		writeInstructor(doc, rootElement, johnathan);
		
		// write the content into xml file
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(doc);
		StreamResult result = new StreamResult(new File("C:/Users/CookSystems/Test.xml"));

		transformer.transform(source, result);

		System.out.println("File saved!");
	}

	private static void writeInstructor(Document doc, Element rootElement, Instructor instructor)
	{
		Element instructorNode = doc.createElement("Instructor");
		instructorNode.setAttribute("id", String.valueOf(instructor.getId()));
		rootElement.appendChild(instructorNode);
		
		// firstname elements
		Element firstname = doc.createElement("firstName");
		firstname.appendChild(doc.createTextNode(instructor.getFirstName()));
		instructorNode.appendChild(firstname);

		// lastname elements
		Element lastname = doc.createElement("lastName");
		lastname.appendChild(doc.createTextNode(instructor.getLastName()));
		instructorNode.appendChild(lastname);

		// home town elements
		Element nickname = doc.createElement("homeTown");
		nickname.appendChild(doc.createTextNode(instructor.getHomeTown()));
		instructorNode.appendChild(nickname);

		// favorite planet elements
		Element salary = doc.createElement("favoritePlanet");
		salary.appendChild(doc.createTextNode(instructor.getFavoritePlanet()));
		instructorNode.appendChild(salary);
	}
}
