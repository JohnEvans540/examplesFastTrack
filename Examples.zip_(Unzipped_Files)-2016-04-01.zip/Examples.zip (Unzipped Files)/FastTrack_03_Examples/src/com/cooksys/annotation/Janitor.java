package com.cooksys.annotation;

@UnderManagement(department = "Facilities")
public class Janitor extends Employee
{

}
