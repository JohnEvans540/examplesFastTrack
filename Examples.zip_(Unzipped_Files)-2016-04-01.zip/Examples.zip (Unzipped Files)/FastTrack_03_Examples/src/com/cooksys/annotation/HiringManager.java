package com.cooksys.annotation;

@UnderManagement(department = "HR")
public class HiringManager extends Employee
{

}
