package com.cooksys.annotation;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;

public class ManagementReader
{

	public static void main(String[] args)
	{

		Freelancer freeLancer = new Freelancer();
		HiringManager hiringManager = new HiringManager();
		Janitor janitor = new Janitor();
		Programmer programmer = new Programmer();

		ArrayList<Employee> empList = new ArrayList<>();

		empList.add(freeLancer);
		empList.add(hiringManager);
		empList.add(janitor);
		empList.add(programmer);

		for (Employee e : empList)
		{
			UnderManagement m = e.getClass().getAnnotation(UnderManagement.class);
			
			if (m != null)
				System.out.println(m.department());
			else
				System.out.println("Employee is not under management");

			// method time

			try
			{

				for (Method method : e.getClass().getDeclaredMethods())
				{

					ImportantData data;
					if ((data = method.getAnnotation(ImportantData.class)) != null)
					{
						
						System.out.println(data.value() + " : " + method.invoke(e).toString());

					}

				}

			}
			catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e1)
			{
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

		}

	}
}