package com.cooksys.annotation;

public class Freelancer extends Employee
{

}
