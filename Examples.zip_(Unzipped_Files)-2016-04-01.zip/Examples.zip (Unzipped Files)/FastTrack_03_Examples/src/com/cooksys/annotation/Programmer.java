package com.cooksys.annotation;

@UnderManagement(department = "IT")
public class Programmer extends Employee
{
	@ImportantData(value = "code")
	public String writeCode()
	{
		return "beep boop computer code";
	}
	
}
