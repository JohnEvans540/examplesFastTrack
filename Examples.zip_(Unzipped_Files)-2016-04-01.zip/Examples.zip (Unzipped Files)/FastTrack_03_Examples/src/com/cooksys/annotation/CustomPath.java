package com.cooksys.annotation;

public @interface CustomPath
{

}
