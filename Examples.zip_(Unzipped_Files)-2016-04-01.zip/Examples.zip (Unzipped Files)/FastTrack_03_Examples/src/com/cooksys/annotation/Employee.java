package com.cooksys.annotation;

public class Employee
{
	public String name;
}
