package com.cooksys.samples.networking;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Server
{
	public static void main(String[] args) throws IOException
	{
		ServerSocket serverSocket = new ServerSocket(8080);
		
		System.out.println("Server waiting for connection...");
		Socket recievedConnection = serverSocket.accept();
		System.out.println("Connection recieved! Address of client: " + recievedConnection.getRemoteSocketAddress());
		
		DataOutputStream os = new DataOutputStream(recievedConnection.getOutputStream());
		
		os.writeUTF("Welcome, you have connected to the server!");
		
		InputStream is = recievedConnection.getInputStream();
		
		DataInputStream reader = new DataInputStream(is);
		
		System.out.println("Client responded: " + reader.readUTF());
		
		is.close();
		os.close();
		
		serverSocket.close();
	}
}
