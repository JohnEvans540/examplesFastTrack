package com.cooksys.samples.networking;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class Client
{
	public static void main(String[] args) throws IOException
	{
		Socket s = new Socket("127.0.0.1", 8080);
		System.out.println("Connecting to socket");
		
		DataInputStream is = new DataInputStream(s.getInputStream());
		
		System.out.println("Connected to Server."
				+ "\nServer sent message: " + is.readUTF());
		
		DataOutputStream os = new DataOutputStream(s.getOutputStream());
		
		os.writeUTF("Thank you for the message!");
		os.flush();
		
		is.close();
		os.close();
		
		s.close();
	}
}
